#!/system/bin/sh

echo "
( Shell ) : resetting the settings that have been changed, Please wait!
"
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0
echo "( Pull File ) settings2-adb.so / settings1-adb.so"
cd /storage/emulated/0/android/data/com.android.systemui.optimization
mv settings1-adb.so /sdcard
mv settings2-adb.so /sdcard
echo "( Shell ) : Currently deleting custom folder in /android/data, please wait"
rm -rf /storage/emulated/0/android/data/com.android.systemui.optimization
echo
echo "Force-Restart ( StatusCode : 0 ) ..."
echo "Rebooting..."
svc power reboot
reboot